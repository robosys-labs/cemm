"""Small independent Decimal replay of saved recovery checkpoint witnesses."""
from decimal import Decimal, localcontext
from hashlib import sha256
from pathlib import Path
import json

ROOT = Path('/workspace/scratch/e21db99b0f7d/persistence-validation')
reports = {s: json.loads((ROOT/'run-1'/f'{s}.json').read_text()) for s in ('produce','resume')}
rows = {s: {r['key']:r for r in v['records']} for s,v in reports.items()}
keys = sorted(rows['produce'])
# Fixed sorted positions, independent of outcome or prediction quality.
selected = [keys[i] for i in (0, len(keys)//2, len(keys)-1)]
records = []
with localcontext() as ctx:
    ctx.prec = 80
    for key in selected:
        earlier = None
        for stage in ('produce','resume'):
            record = rows[stage][key]
            reference = record['checkpoint']
            raw = [(ROOT/f'run-{i}'/reference['file']).read_bytes() for i in (1,2)]
            assert raw[0] == raw[1]
            assert sha256(raw[0]).hexdigest() == reference['sha256']
            checkpoint = json.loads(raw[0], parse_float=Decimal)
            assert len(checkpoint['deliveries']) == (1 if stage=='produce' else 2)
            if earlier is not None:
                assert checkpoint['deliveries'][0] == earlier['deliveries'][0]
                assert checkpoint['frame'] == earlier['frame']
                assert checkpoint['source_sha256'] == earlier['source_sha256']
            p = checkpoint['initial_prior']
            p = [x/sum(p) for x in p]
            ids = set()
            for d in checkpoint['deliveries']:
                assert d['projection']['evidence_id'] not in ids
                ids.add(d['projection']['evidence_id'])
                l = d['projection']['likelihood']
                l = [[x/sum(row) for x in row] for row in l]
                w = [p[j]*row[d['endpoint']] for j,row in enumerate(l)]
                p = [x/sum(w) for x in w]
            errors = [abs(float(a)-b) for a,b in zip(p, record['posterior'])]
            assert max(errors) < 5e-15
            records.append({'key':key,'phase':stage,'checkpoint_sha256':reference['sha256'],
                            'max_abs_error_80_digit_decimal_vs_report':max(errors)})
            earlier = checkpoint
result = {'status':'PASS','files_read':12,'distinct_checkpoints_replayed':6,
          'source':'saved checkpoint bytes only; stdlib Decimal precision80; no CEMM imports',
          'selected_contexts':selected,'checks':records}
out = ROOT/'third-party-spotcheck.json'
out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True))
